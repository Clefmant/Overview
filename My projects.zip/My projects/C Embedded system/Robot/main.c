#include <msp430.h>
#include "ADC.h"

/**
 * main.c
 */

unsigned int actif = 0;
unsigned int capteurD = 0;
unsigned int capteurG = 0;
unsigned int valeurLimite = 900;    //A changer en fonction de l'environnement
unsigned int vitesseMax = 2000;     //Param�tre la vitesse max
unsigned int vitesseTourner = 0;    //Param�tre la vitesse de la roue du c�t� o� l'on tourne


void avancerRobot();
void tournerDroitRobot();
void valeurCapteur(unsigned int* capteurD, unsigned int* capteurG);
void tournerGaucheRobot();
void init();



int main(void)
{

    WDTCTL = WDTPW | WDTHOLD;   // stop watchdog timer
    init();

    while(1)
    {
        if (actif)
        {
            valeurCapteur (&capteurD, &capteurG);
            /**
            if ((capteurD < valeurLimite) & (capteurG < valeurLimite))
            {
                TA0CTL |= TACLR;
                TA0CTL &= ~TAIFG;
                while(!(TA0CTL & TAIFG));
                valeurCapteur(&capteurD, &capteurG);
            }
            **/
            if ((capteurD > valeurLimite) & (capteurG > valeurLimite))
                avancerRobot();
            if ((capteurD < valeurLimite) & (capteurG > valeurLimite))
                    tournerDroitRobot();
            if ((capteurD > valeurLimite) & (capteurG < valeurLimite))
                    tournerGaucheRobot();
        }
    }
}


//Un appuie sur le bouton d�marre le robot et un deuxi�me appuie l'arr�te
#pragma vector = PORT1_VECTOR
__interrupt void button_push(void)
{
    if (actif == 1)
    {
        actif = 0;
        TA1CCR1 = vitesseTourner;
        TA1CCR2 = vitesseTourner;
    }
    else
        actif = 1;

    P1IFG &= ~BIT3;

}


#pragma vector = TIMER0_A1_VECTOR
__interrupt void tempsEcoule(void)
{
    TA0CTL &= ~TAIFG;
}

void avancerRobot ()
{
    P2OUT &= ~(BIT1);   //Roue gauche    0 avant | 1 arri�re
    P2OUT |= (BIT5);    //Roue droite    1 avant | 0 arri�re
    TA1CCR1 =   vitesseMax;
    TA1CCR2 =   vitesseMax;

}

void tournerGaucheRobot()
{
    do
    {
        TA1CCR2 = vitesseTourner;
        valeurCapteur(&capteurD, &capteurG);
    }while (capteurG > valeurLimite);
        TA1CCR2 = vitesseMax;
}

void tournerDroitRobot()
{
    do
    {
        TA1CCR1 = vitesseTourner;
        valeurCapteur(&capteurD, &capteurG);
    }while(capteurD > valeurLimite);
        TA1CCR1 = vitesseMax;
}

void valeurCapteur(unsigned int* capteurD, unsigned int* capteurG)
{
    //Capteur droit
    ADC_Demarrer_conversion(0x02);
    *capteurD = ADC_Lire_resultat();

    //Capteur gauche
    ADC_Demarrer_conversion(0x01);
    *capteurG = ADC_Lire_resultat();
}

void init()
{

    ADC_init();
    //P2.2: Moteur A = moteur Gauche
    //P2.5 Moteur B = moteur Droite
    //Sens avant moteur A = 0
    //Sens avant moteur B = 1

    //Initialisation moteurs

    P2DIR |= (BIT2 | BIT4 | BIT1 | BIT5);
    P2OUT &= BIT1;
    P2OUT |= BIT5;
    P2SEL |= (BIT2 | BIT4);
    P2SEL2 &= ~(BIT2 | BIT4);

    //Initialisation Clock TA1
    TA1CTL |= 0|(TASSEL_2 | MC_1 | ID_0);  //SMCLK + up + prediv 1

    //Initiatlisation TA1.2 -- Moteur Droit
    TA1CCTL2 |= OUTMOD_7;  // reset set
    TA1CCR0 = 10000; // 0.01ms
    TA1CCR2 = 0;

    //Initialisation TA1.1 -- Moteur Gauche
    TA1CCTL1 |= OUTMOD_7;  // reset set
    TA1CCR0 = 10000; // 0.01ms
    TA1CCR1 = 0;

    //Capteur Droite et gauche
    P1DIR &= ~(BIT1 | BIT2);
    P1SEL &= ~(BIT1 | BIT2);
    P1SEL2 &= ~(BIT1 |BIT2 );

    //Timer pour l'arriv�e
    TA0CTL |= 0|(TASSEL_2 | MC_1 | ID_0);
    TA0CTL &= ~TAIE;
    TA0CCR0 = 62500; //
    TA0CTL &= ~TAIFG;

    //Initialisation bouton
    P1REN |= BIT3;
    P1IE |= BIT3;
    P1IES &= ~BIT3;
    P1IFG &= ~BIT3;

    __enable_interrupt();
}
