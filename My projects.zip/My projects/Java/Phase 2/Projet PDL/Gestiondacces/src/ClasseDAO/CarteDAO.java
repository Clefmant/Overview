/**
* Creation of a person in the DataBase
*
* @author  Cl�ment Sieuw 
* @author2  Boubacar Ndoffane Diakhate
* @version 1.0
* @since   2021-03-22 
*/


package ClasseDAO;


import java.sql.*;
import java.util.ArrayList;
import Classe.Carte;
import Classe.Personne;


public class CarteDAO extends ConnectionDAO{
		
	
	
	public CarteDAO( ) {
		super();		
	}
	
	/**
	 * Take all the informations about a person and add it to the Data Base
	 * 
	 * @param personne to save
	 * @return
	 */
	public static int create(Carte carte) {
	
		Connection con = null;
		PreparedStatement ps = null;
		int returnValue = 0;
		
		try {
			con = DriverManager.getConnection(URL, LOGIN, PASS);
			ps = con.prepareStatement("INSERT INTO Carte (idcarte, etatblocagecarte, idpersonne) VALUES (IDCARTE.nextval,?, ?)");
			ps.setInt(1, carte.getEtatBlocageCarte());
			ps.setInt(2, carte.getPersonne().getIdPersonne());  
			
			returnValue = ps.executeUpdate();		
		}catch (Exception e) {
			if (e.getMessage().contains("ORA-00001")) { 
				return 0;
				//Error();
			
			}else
				e.printStackTrace();
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (con != null) {
				con.close();
				}
			} catch (Exception ignore) {
			}
		}
		return returnValue;
		
	}
	
	/**
	 * Update the informations about a person and add it to the Data Base
	 * 
	 * @param personne to update
	 * @return
	 */
	
	public static int checking(int idpersonne) {
		Connection con = null;
		PreparedStatement ps = null;
		int returnValue = 0;
		
		try {
			con = DriverManager.getConnection(URL, LOGIN, PASS);
		
			ps = con.prepareStatement("SELECT COUNT(*) FROM CARTE WHERE idpersonne = ?");
		
			ps.setInt(1, idpersonne);
			
		// Execution de la requete
			returnValue = ps.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		
		} finally {
			try {
					if (ps != null) {
							ps.close();
					}
			}catch (Exception ignore) {
			}
			
			try {
				if (con != null) {
					con.close();
				}
			}catch (Exception ignore) {
			}
		}
		return returnValue;
		}

	
	/**
	 * Delete a person from the Data Base
	 * 
	 * @param i  idpersonne of the person to delete
	 * @return
	 */
	
	public static int delete(int i) {
		Connection con = null;
		PreparedStatement ps = null;
		int returnValue =0;
		
		try {
			con = DriverManager.getConnection(URL,LOGIN, PASS);
			
			ps = con.prepareStatement("DELETE FROM Carte WHERE idpersonne = ?");
			ps.setInt(1, i);
			returnValue = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
			}catch (Exception ignore) {
			}
			try {
				if (con != null) {
					con.close();
				}
			}catch (Exception ignore) {
			}
		}
		return returnValue;
	}
	
	
	
	/**
	 * Look for all the person in the DataBase and add them to a list
	 * @return a list with all the person
	 */
	public static ArrayList<Carte> getList(int etatBlocageCarte){
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		ArrayList<Carte> returnValue = new ArrayList<>();
		
		try {
			con = DriverManager.getConnection (URL, LOGIN, PASS);
			
			if (etatBlocageCarte == 0) {
				ps=con.prepareStatement("SELECT * FROM personne WHERE etatblocagecarte = ?");
				ps.setInt(1, etatBlocageCarte);
			}
			
			if (etatBlocageCarte == 1) {
				ps=con.prepareStatement("SELECT * FROM personne  WHERE etatblocagecarte = ?");
				ps.setInt(1, etatBlocageCarte);
			}
			
			else {
				ps=con.prepareStatement("SELECT * FROM personne");
			}
			rs = ps.executeQuery();
			while(rs.next()) {
				returnValue.add(new Carte(rs.getInt("idcarte") ,PersonneDAO.get(rs.getInt("idpersonne"))));
				
			}
		}catch(Exception ee) {
			ee.printStackTrace();
		}finally {
			try {
				if (rs != null) {
					rs.close();
				}
			}catch (Exception ignore) {
			}
			try {
				if (ps != null) {
					ps.close();
				}
			}catch (Exception ignore) {
			}
			try {
				if (con != null) {
					con.close();
				}
			}catch (Exception ignore) {
			}
		}
		return returnValue;
	}
		
	
	
	
	
	
	
	
	
}
