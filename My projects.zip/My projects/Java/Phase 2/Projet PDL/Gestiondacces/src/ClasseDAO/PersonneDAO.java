/**
* Creation of a person in the DataBase
*
* @author  Cl�ment Sieuw 
* @author2  Boubacar Ndoffane Diakhate
* @version 1.0
* @since   2021-03-22 
*/


package ClasseDAO;


import java.sql.*;
import java.util.ArrayList;

import Classe.Personne;


public class PersonneDAO extends ConnectionDAO{
		
	
	
	public PersonneDAO( ) {
		super();		
	}
	
	/**
	 * Take all the informations about a person and add it to the Data Base
	 * 
	 * @param personne to save
	 * @return
	 */
	public static int create(Personne personne) {
	
		Connection con = null;
		PreparedStatement ps = null;
		int returnValue = 0;
		
		try {
			con = DriverManager.getConnection(URL, LOGIN, PASS);
			ps = con.prepareStatement("INSERT INTO PERSONNE (idpersonne, nom, prenom, dateDeNaissance, fonction) VALUES (IDPERSONNE.nextval,?, ?, ?, ?)");
			ps.setString(1, personne.getNom());
			ps.setString(2, personne.getPrenom());
			ps.setDate(3, personne.getDateDeNaissance());
			ps.setString(4, personne.getFonction());
			
			returnValue = ps.executeUpdate();		
		}catch (Exception e) {
			if (e.getMessage().contains("ORA-00001")) { 
				return 0;
				//erreur();
			
			}else
				e.printStackTrace();
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception ignore) {
			}
			try {
				if (con != null) {
				con.close();
				}
			} catch (Exception ignore) {
			}
		}
		return returnValue;
		
	}
	
	/**
	 * Update the informations about a person and add it to the Data Base
	 * 
	 * @param personne to update
	 * @return
	 */
	
	public static int update(Personne personne) {
		Connection con = null;
		PreparedStatement ps = null;
		int returnValue = 0;
		
		try {
			con = DriverManager.getConnection(URL, LOGIN, PASS);
		
			ps = con.prepareStatement("UPDATE personne SET nom = ?, fonction = ? WHERE idpersonne = ?");
		
			ps.setString(1, personne.getNom());
			ps.setString(2, personne.getFonction());
			ps.setInt(3, personne.getIdPersonne());
			System.out.println(personne.getNom());
			System.out.println(personne.getIdPersonne());
			
		// Execution de la requete
			returnValue = ps.executeUpdate();
			
		} catch (Exception e) {
			e.printStackTrace();
		
		} finally {
			try {
					if (ps != null) {
							ps.close();
					}
			}catch (Exception ignore) {
			}
			
			try {
				if (con != null) {
					con.close();
				}
			}catch (Exception ignore) {
			}
		}
		return returnValue;
		}

	
	/**
	 * Delete a person from the Data Base
	 * 
	 * @param i  idpersonne of the person to delete
	 * @return
	 */
	
	public static int delete(int i) {
		Connection con = null;
		PreparedStatement ps = null;
		int returnValue =0;
		
		try {
			con = DriverManager.getConnection(URL,LOGIN, PASS);
			
			ps = con.prepareStatement("DELETE FROM PERSONNE WHERE idpersonne = ?");
			ps.setInt(1, i);
			returnValue = ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
			}catch (Exception ignore) {
			}
			try {
				if (con != null) {
					con.close();
				}
			}catch (Exception ignore) {
			}
		}
		return returnValue;
	}
	
	/**
	 * Search a person from the DataBase and instanciate a person with the DataBase informations
	 * 
	 * @param nom name of the wanted person
	 * @param prenom surname of the wanted person
	 * @return personne
	 */
	
	public static Personne get(int idpersonne) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Personne returnValue = null;
		
		try {
			con = DriverManager.getConnection (URL, LOGIN, PASS);
			ps=con.prepareStatement("SELECT * FROM personne WHERE idpersonne = ?");
			ps.setInt(1, idpersonne);
					
			rs = ps.executeQuery();
			if(rs.next()) {
				returnValue = new Personne (rs.getInt("idpersonne"),  rs.getString("nom"), rs.getString("prenom"), rs.getDate("datedenaissance"), rs.getString("fonction"));
				
			}
		}catch(Exception ee) {
			ee.printStackTrace();
		}finally {
			try {
				if (rs != null) {
					rs.close();
				}
			}catch (Exception ignore) {
			}
			try {
				if (ps != null) {
					ps.close();
				}
			}catch (Exception ignore) {
			}
			try {
				if (con != null) {
					con.close();
				}
			}catch (Exception ignore) {
			}
		}
		return returnValue;
	}
	
	public static Personne get(String nom, String prenom) {
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Personne returnValue = null;
		
		try {
			con = DriverManager.getConnection (URL, LOGIN, PASS);
			ps=con.prepareStatement("SELECT * FROM personne WHERE nom = ? AND prenom = ?");
			ps.setString(1, nom);
			ps.setString(2, prenom);
			
			
			
			rs = ps.executeQuery();
			if(rs.next()) {
				returnValue = new Personne (rs.getInt("idpersonne"),  rs.getString("nom"), rs.getString("prenom"), rs.getDate("datedenaissance"), rs.getString("fonction"));
				
			}
		}catch(Exception ee) {
			ee.printStackTrace();
		}finally {
			try {
				if (rs != null) {
					rs.close();
				}
			}catch (Exception ignore) {
			}
			try {
				if (ps != null) {
					ps.close();
				}
			}catch (Exception ignore) {
			}
			try {
				if (con != null) {
					con.close();
				}
			}catch (Exception ignore) {
			}
		}
		return returnValue;
	}
	
	
	/**
	 * Look for all the person in the DataBase and add them to a list
	 * @return a list with all the person
	 */
	public static ArrayList<Personne> getList(){
		Connection con = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		ArrayList<Personne> returnValue = new ArrayList<>();
		
		try {
			con = DriverManager.getConnection (URL, LOGIN, PASS);
			ps=con.prepareStatement("SELECT * FROM personne");
			
			rs = ps.executeQuery();
			while(rs.next()) {
				returnValue.add(new Personne(rs.getInt("idpersonne") ,rs.getString("nom"), rs.getString("prenom"), rs.getDate("datedenaissance"), rs.getString("fonction")));
				
			}
		}catch(Exception ee) {
			ee.printStackTrace();
		}finally {
			try {
				if (rs != null) {
					rs.close();
				}
			}catch (Exception ignore) {
			}
			try {
				if (ps != null) {
					ps.close();
				}
			}catch (Exception ignore) {
			}
			try {
				if (con != null) {
					con.close();
				}
			}catch (Exception ignore) {
			}
		}
		return returnValue;
	}
		
	
	
	
	
	
	
	
	
}
