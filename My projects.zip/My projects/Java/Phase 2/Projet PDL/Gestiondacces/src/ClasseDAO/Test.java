package ClasseDAO;

import java.sql.Date;

import Classe.Personne;

public class Test extends PersonneDAO{

	public static void main(String[] args) {
		Date date = new Date (2000-1900, 05-1,30);
		Personne a = new Personne ("Cl�ment", "Sieuw",date,"Etudiant");
		a.display();

		PersonneDAO.create(a);
		
	}

}
