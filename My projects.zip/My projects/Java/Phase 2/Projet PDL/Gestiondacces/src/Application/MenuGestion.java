package Application;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLayeredPane;
import java.awt.BorderLayout;
import java.awt.Button;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Panel;
import javax.swing.SwingConstants;
import javax.swing.table.TableModel;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.ListModel;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JList;
import javax.swing.JComboBox;
import java.awt.Color;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import Classe.*;
import ClasseDAO.*;
import javax.swing.JMenuItem;
import java.awt.Choice;

public class MenuGestion extends JFrame{

	private JFrame frmGestion;
	private JTextField nomCreerPersonne;
	private JTextField prenomCreerPersonne;
	private JTextField dateDeNaissanceCreerPersonne;
	private JTextField fonctionCreerPersonne;
	private JTextField rechercheNomPersonneModif;
	private JTextField rechercherPrenomPersonneModif;
	private JTextField nomPersonneModif;
	private JTextField fonctionPersonneModif;
	private JTextField nomSupprimerPersonne;
	private JTextField prenomSupprimerPersonne;
	private Panel currentPanel = null;
	private Panel previousPanel = null;
	private int personneExiste;
	private JList<String> list;
	private JList<String> list1;
	private int k = 0;
	private int h = 0;
	private Personne personneModif; 
    private	DefaultListModel modeleModif= new DefaultListModel();
    private	DefaultListModel modeleSupprimer= new DefaultListModel();
    
	
	/**
	 * Launch the application.
	 */
	
	public JFrame getJFrame() {
		return this.frmGestion;
	}
	 
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MenuGestion window = new MenuGestion(0);
					window.frmGestion.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	/**
	 * Create the application.
	 */
	
	
	
	
	
	
	
	public MenuGestion(int a) {
		initialize(a);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize(int a) {
		setLocationRelativeTo(null);
		frmGestion = new JFrame();
		frmGestion.setTitle("Gestion");
		frmGestion.setBounds(100, 100, 631, 436);
		frmGestion.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//The Application frame
		JLayeredPane layeredPane = new JLayeredPane();
		frmGestion.getContentPane().add(layeredPane, BorderLayout.CENTER);
		layeredPane.setLayout(null);
		
		

		
		//The different menus panels
		Panel menugerer = new Panel();
		layeredPane.setLayer(menugerer, 1);
		menugerer.setBounds(0, 23, 615, 334);
		layeredPane.add(menugerer);
		menugerer.setLayout(null);
		
		Panel gererLesPersonnesMenu = new Panel();
		gererLesPersonnesMenu.setBounds(0, 23, 615, 334);
		layeredPane.setLayer(gererLesPersonnesMenu, 0);
		layeredPane.add(gererLesPersonnesMenu);
		gererLesPersonnesMenu.setLayout(null);
		
		Panel gererLesLieuxMenu = new Panel();
		layeredPane.setLayer(gererLesLieuxMenu, a);
		gererLesLieuxMenu.setLayout(null);
		gererLesLieuxMenu.setBounds(0, 23, 615, 334);
		layeredPane.add(gererLesLieuxMenu);
		
		Panel gererLesCartesMenu = new Panel();
		layeredPane.setLayer(gererLesCartesMenu, a);
		gererLesCartesMenu.setLayout(null);
		gererLesCartesMenu.setBounds(0, 23, 615, 334);
		layeredPane.add(gererLesCartesMenu);
		
		
		Panel modifierUnePersonne = new Panel();
		layeredPane.setLayer(modifierUnePersonne, 0);
		modifierUnePersonne.setLayout(null);
		modifierUnePersonne.setBounds(0, 23, 615, 334);
		layeredPane.add(modifierUnePersonne);
		
		JLayeredPane layeredPane_1 = new JLayeredPane();
		layeredPane_1.setBounds(0, 0, 615, 334);
		modifierUnePersonne.add(layeredPane_1);
		layeredPane_1.setLayout(null);
		
		Panel supprimerUnePersonne = new Panel();
		layeredPane.setLayer(supprimerUnePersonne, 0);
		supprimerUnePersonne.setLayout(null);
		supprimerUnePersonne.setBounds(0, 23, 615, 334);
		layeredPane.add(supprimerUnePersonne);
		
		JLayeredPane layeredPane_1_1 = new JLayeredPane();
		layeredPane_1_1.setLayout(null);
		layeredPane_1_1.setBounds(0, 0, 615, 334);
		supprimerUnePersonne.add(layeredPane_1_1);
		
		JPanel listeSupprimerPersonne = new JPanel();
		layeredPane_1_1.setLayer(listeSupprimerPersonne, 0);
		listeSupprimerPersonne.setLayout(null);
		listeSupprimerPersonne.setBounds(0, 0, 615, 334);
		layeredPane_1_1.add(listeSupprimerPersonne);
		
		JPanel listeModifPersonne = new JPanel();
		listeModifPersonne.setBounds(0, 0, 615, 334);
		layeredPane_1.setLayer(listeModifPersonne, 0);
		layeredPane_1.add(listeModifPersonne);
		listeModifPersonne.setLayout(null);

		JPanel rechercheModifPersonne = new JPanel();
		rechercheModifPersonne.setBounds(0, 0, 615, 334);
		layeredPane_1.setLayer(rechercheModifPersonne, 1);
		layeredPane_1.add(rechercheModifPersonne);
		rechercheModifPersonne.setLayout(null);
		
		Panel modifUnePersonne = new Panel();
		layeredPane_1.setLayer(modifUnePersonne, a);
		modifUnePersonne.setLayout(null);
		modifUnePersonne.setBounds(0, 0, 615, 334);
		layeredPane_1.add(modifUnePersonne);
		
		JPanel validationInformation = new JPanel();
		layeredPane.setLayer(validationInformation, 0);
		validationInformation.setBounds(0, 23, 615, 333);
		layeredPane.add(validationInformation);
		validationInformation.setLayout(null);
	
				
		JPanel rechercheSupprimerPersonne = new JPanel();
		layeredPane_1_1.setLayer(rechercheSupprimerPersonne, a + 1);
		rechercheSupprimerPersonne.setLayout(null);
		rechercheSupprimerPersonne.setBounds(0, 0, 615, 334);
		layeredPane_1_1.add(rechercheSupprimerPersonne);
		
		Panel creerUnePersonne = new Panel();
		layeredPane.setLayer(creerUnePersonne, a);
		creerUnePersonne.setLayout(null);
		creerUnePersonne.setBounds(0, 23, 615, 334);
		layeredPane.add(creerUnePersonne);
	    
		
	    JScrollPane scrollBar = new JScrollPane();
		scrollBar.setBounds(498, 99, 17, 147);

		
	    
		nomCreerPersonne = new JTextField();
		nomCreerPersonne.setBounds(206, 93, 300, 20);
		creerUnePersonne.add(nomCreerPersonne);
		nomCreerPersonne.setColumns(10);
		
		prenomCreerPersonne = new JTextField();
		prenomCreerPersonne.setColumns(10);
		prenomCreerPersonne.setBounds(206, 131, 300, 20);
		creerUnePersonne.add(prenomCreerPersonne);
		
		dateDeNaissanceCreerPersonne = new JTextField();
		dateDeNaissanceCreerPersonne.setColumns(10);
		dateDeNaissanceCreerPersonne.setBounds(206, 172, 300, 20);
		creerUnePersonne.add(dateDeNaissanceCreerPersonne);
		
		fonctionCreerPersonne = new JTextField();
		fonctionCreerPersonne.setColumns(10);
		fonctionCreerPersonne.setBounds(206, 210, 300, 20);
		creerUnePersonne.add(fonctionCreerPersonne);
		
		rechercheNomPersonneModif = new JTextField();
		rechercheNomPersonneModif.setBounds(182, 124, 322, 20);
		rechercheModifPersonne.add(rechercheNomPersonneModif);
		rechercheNomPersonneModif.setColumns(10);
		
		rechercherPrenomPersonneModif = new JTextField();
		rechercherPrenomPersonneModif.setColumns(10);
		rechercherPrenomPersonneModif.setBounds(182, 163, 322, 20);
		rechercheModifPersonne.add(rechercherPrenomPersonneModif);
		
		nomPersonneModif = new JTextField();
		nomPersonneModif.setColumns(10);
		nomPersonneModif.setBounds(206, 93, 300, 20);
		modifUnePersonne.add(nomPersonneModif);
		
		fonctionPersonneModif = new JTextField();
		fonctionPersonneModif.setColumns(10);
		fonctionPersonneModif.setBounds(206, 210, 300, 20);
		modifUnePersonne.add(fonctionPersonneModif);
		
		nomSupprimerPersonne = new JTextField();
		nomSupprimerPersonne.setColumns(10);
		nomSupprimerPersonne.setBounds(182, 124, 322, 20);
		rechercheSupprimerPersonne.add(nomSupprimerPersonne);
		
		prenomSupprimerPersonne = new JTextField();
		prenomSupprimerPersonne.setColumns(10);
		prenomSupprimerPersonne.setBounds(182, 163, 322, 20);
		rechercheSupprimerPersonne.add(prenomSupprimerPersonne);
		
		
		JLabel errorMessageCreerPersonne = new JLabel("");
		errorMessageCreerPersonne.setBounds(95, 248, 411, 14);
		creerUnePersonne.add(errorMessageCreerPersonne);		
		
		JLabel errorMessageModifUnePersonne = new JLabel("");
		errorMessageModifUnePersonne.setBounds(95, 248, 411, 14);
		modifUnePersonne.add(errorMessageModifUnePersonne);		
		
		JLabel prenomPersonneModif = new JLabel("a");
		prenomPersonneModif.setForeground(Color.GRAY);
		prenomPersonneModif.setBounds(206, 134, 300, 14);
		modifUnePersonne.add(prenomPersonneModif);
		
		JLabel dateDeNaissancePersonneModif = new JLabel("a");
		dateDeNaissancePersonneModif.setForeground(Color.GRAY);
		dateDeNaissancePersonneModif.setBounds(205, 172, 305, 14);
		modifUnePersonne.add(dateDeNaissancePersonneModif);
		
		JLabel errorMessageModifPersonne = new JLabel("");
		errorMessageModifPersonne.setHorizontalAlignment(SwingConstants.LEFT);
		errorMessageModifPersonne.setForeground(Color.RED);
		errorMessageModifPersonne.setBounds(95, 248, 411, 14);
		modifUnePersonne.add(errorMessageModifPersonne);
		

		JLabel errorMessageSupprimerPersonne_1 = new JLabel("");
		errorMessageSupprimerPersonne_1.setHorizontalAlignment(SwingConstants.LEFT);
		errorMessageSupprimerPersonne_1.setForeground(Color.RED);
		errorMessageSupprimerPersonne_1.setBounds(139, 212, 411, 14);
		rechercheSupprimerPersonne.add(errorMessageSupprimerPersonne_1);	
		
		
		JList<String> listSupprimerPersonneJList = new JList<>();

        JScrollPane scrollPaneSupprimer = new JScrollPane(listSupprimerPersonneJList);
        scrollPaneSupprimer.setViewportView(listSupprimerPersonneJList);
        listSupprimerPersonneJList.setLayoutOrientation(JList.VERTICAL);
        listeSupprimerPersonne.add(scrollPaneSupprimer);
        scrollPaneSupprimer.setBounds(26, 99, 564, 150);
        /**
        JScrollPane bar = new JScrollPane(list);
        list.setLayoutOrientation(JList.VERTICAL);

        bar.setBounds(89, 41, 250, 157);
        frame.getContentPane().add(bar);
        bar.setVisible(true);
        **/


        JList<String> listModifierPersonneJList = new JList<>();

        JScrollPane scrollPaneModifier = new JScrollPane(listModifierPersonneJList);
        listModifierPersonneJList.setLayoutOrientation(JList.VERTICAL);
        scrollPaneModifier.setBounds(26, 99, 564, 185);
		scrollPaneModifier.setVisible(true);
		listeModifPersonne.add(scrollPaneModifier);
		
		//The return button
		JButton btnNewButton = new JButton("");
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\funta\\Desktop\\Programmation\\Code\\S6 ing\u00E9\\Fichier PDL\\Retour application.png"));
		btnNewButton.setBounds(10, 3, 32, 20);
		layeredPane.add(btnNewButton);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (currentPanel == menugerer);
				if((currentPanel == gererLesPersonnesMenu) || (currentPanel == gererLesCartesMenu) || (currentPanel == gererLesLieuxMenu)) {
					layeredPane.setLayer(currentPanel, 0);
					layeredPane.setLayer(menugerer, 1);
				}

				else {
					layeredPane.setLayer(currentPanel, 0);
					layeredPane.setLayer(previousPanel, 1);	
					currentPanel = previousPanel;
					errorMessageCreerPersonne.setText("");
					errorMessageModifPersonne.setText("");
					errorMessageModifUnePersonne.setText("");
					errorMessageSupprimerPersonne_1.setText("");
					layeredPane_1.setLayer(rechercheModifPersonne, 1);
					layeredPane_1.setLayer(listeModifPersonne, 0);
					layeredPane_1.setLayer(modifUnePersonne, 0);
					layeredPane_1_1.setLayer(rechercheSupprimerPersonne, 1);
					layeredPane_1_1.setLayer(listeSupprimerPersonne, 0);
					for (int j = modeleModif.size() -1; j >= 0; j--) {
						modeleModif.remove(j);	
					}
					for (int j = modeleSupprimer.size() -1; j >= 0; j--) {
						modeleSupprimer.remove(j);	
					}
				}
			}
		});
		
		JButton boutonValidationPersonne = new JButton("Ok");
		boutonValidationPersonne.setBounds(257, 262, 89, 23);
		validationInformation.add(boutonValidationPersonne);
		boutonValidationPersonne.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				layeredPane.setLayer(validationInformation, 0);	
				layeredPane.setLayer(menugerer, 1);
				layeredPane.setLayer(creerUnePersonne, 0);
				layeredPane.setLayer(supprimerUnePersonne, 0);
				layeredPane.setLayer(modifierUnePersonne, 0);
				errorMessageCreerPersonne.setText("");
				currentPanel = menugerer;
				previousPanel = null;
				errorMessageCreerPersonne.setText("");
				errorMessageModifPersonne.setText("");
				errorMessageSupprimerPersonne_1.setText("");
				layeredPane_1.setLayer(rechercheModifPersonne, 1);
				layeredPane_1.setLayer(listeModifPersonne, 0);
				layeredPane_1.setLayer(modifUnePersonne, 0);
				layeredPane_1_1.setLayer(rechercheSupprimerPersonne, 1);
				layeredPane_1_1.setLayer(listeSupprimerPersonne, 0);
			}
		});		
		
		
		//The different buttons
		
		JButton listeValidationSupprimerPersonne = new JButton("Valider");
		listeValidationSupprimerPersonne.setBounds(209, 263, 183, 23);
		listeSupprimerPersonne.add(listeValidationSupprimerPersonne);
	
		
		Button debloquerUneCarte_1 = new Button("D\u00E9bloquer une carte");
		debloquerUneCarte_1.setBounds(72, 266, 456, 22);
		gererLesCartesMenu.add(debloquerUneCarte_1);
		
		
		Button gererLesLieux = new Button("G\u00E9rer les lieux");
		gererLesLieux.setBounds(80, 227, 456, 22);
		menugerer.add(gererLesLieux);
		
		
		Button gererLesCartes = new Button("G\u00E9rer les cartes");
		gererLesCartes.setBounds(80, 194, 456, 22);
		menugerer.add(gererLesCartes);
		layeredPane.setLayer(gererLesCartes, 1);
		gererLesCartes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		
		
		
		Button gererLesPersonnes = new Button("G\u00E9rer les personnes");
		gererLesPersonnes.setBounds(80, 158, 456, 22);
		menugerer.add(gererLesPersonnes);
		layeredPane.setLayer(gererLesPersonnes, 0);
		gererLesPersonnes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				layeredPane.setLayer(menugerer, 0);
				layeredPane.setLayer(gererLesPersonnesMenu, 1);
				currentPanel = gererLesPersonnesMenu;
				previousPanel = menugerer;
				
			}
		});
		
		
		Button supprimerDesPersonnes = new Button("Supprimer les personnes");
		supprimerDesPersonnes.setBounds(72, 236, 456, 22);
		gererLesPersonnesMenu.add(supprimerDesPersonnes);
		supprimerDesPersonnes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {;
				layeredPane.setLayer(gererLesPersonnesMenu, 0);
				layeredPane.setLayer(supprimerUnePersonne, 1);
				currentPanel = supprimerUnePersonne;
				previousPanel = gererLesPersonnesMenu; 
			}
		});
		
		
		

		Button modifierPersonne = new Button("Modifier des personnes");
		modifierPersonne.setBounds(72, 188, 456, 22);
		gererLesPersonnesMenu.add(modifierPersonne);
		modifierPersonne.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				layeredPane.setLayer(gererLesPersonnesMenu, 0);
				layeredPane.setLayer(modifierUnePersonne, 1);
				currentPanel = modifierUnePersonne;
				previousPanel = gererLesPersonnesMenu;
			}
		});
		
		Button creerLesPersonnes = new Button("Cr\u00E9er des personnes");
		creerLesPersonnes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				layeredPane.setLayer(gererLesPersonnesMenu, 0);
				layeredPane.setLayer(creerUnePersonne, 1);
				currentPanel = creerUnePersonne;
				previousPanel = gererLesPersonnesMenu;
			}
		});
		creerLesPersonnes.setBounds(72, 141, 456, 22);
		gererLesPersonnesMenu.add(creerLesPersonnes);
		
		Button bloquerLieu = new Button("Bloquer un lieu");
		bloquerLieu.setBounds(72, 198, 456, 22);
		gererLesLieuxMenu.add(bloquerLieu);
		bloquerLieu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		
		Button supprimerUnLieu = new Button("Supprimer un lieu");
		supprimerUnLieu.setBounds(72, 160, 456, 22);
		gererLesLieuxMenu.add(supprimerUnLieu);
		supprimerUnLieu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		Button creerUnlieu = new Button("Cr\u00E9er un lieu");
		creerUnlieu.setBounds(72, 120, 456, 22);
		gererLesLieuxMenu.add(creerUnlieu);
		creerUnlieu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		
		Button debloquerUnLieu = new Button("D\u00E9bloquer un lieu");
		debloquerUnLieu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		debloquerUnLieu.setBounds(72, 236, 456, 22);
		gererLesLieuxMenu.add(debloquerUnLieu);
		
		
		
		Button bloquerCarte = new Button("Bloquer une carte");
		bloquerCarte.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		bloquerCarte.setBounds(72, 223, 456, 22);
		gererLesCartesMenu.add(bloquerCarte);
		
		Button supprimerUneCarte_1 = new Button("Supprimer une carte");
		supprimerUneCarte_1.setBounds(72, 181, 456, 22);
		gererLesCartesMenu.add(supprimerUneCarte_1);
		
		Button creerUneCarte_1 = new Button("Cr\u00E9er une carte");
		creerUneCarte_1.setBounds(72, 141, 456, 22);
		gererLesCartesMenu.add(creerUneCarte_1);
		
		JButton validerRecherchePersonneSupprimer = new JButton("Valider");
		validerRecherchePersonneSupprimer.setBounds(238, 237, 116, 41);
		rechercheSupprimerPersonne.add(validerRecherchePersonneSupprimer);
		validerRecherchePersonneSupprimer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ee) {
				String nom = nomSupprimerPersonne.getText(); 
				String prenom = prenomSupprimerPersonne.getText();
				if((nom == "") || (prenom == "")) {
					errorMessageSupprimerPersonne_1.setText("Veuillez remplir tous les champs !");
				}
				else {
					Personne personneSupprimer = PersonneDAO.get(nom, prenom);
					if (personneSupprimer != null) {
						PersonneDAO.delete(personneSupprimer.getIdPersonne());
						System.out.println(personneSupprimer.getIdPersonne());
						
					}
					else {
						errorMessageSupprimerPersonne_1.setText("Personne introuvable");
					}
				}
			}	
		});		
	
		
		
		JButton validerCreationPersonne = new JButton("Valider");
		validerCreationPersonne.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				String resultVerificationCreerPersonne = verificationCreerPersonne(nomCreerPersonne.getText(), prenomCreerPersonne.getText(), dateDeNaissanceCreerPersonne.getText(), fonctionCreerPersonne.getText());	
				if (resultVerificationCreerPersonne == "Un champ n'est pas valide") {
					errorMessageCreerPersonne.setText(resultVerificationCreerPersonne);
				}
				if (resultVerificationCreerPersonne == "ok"){
					if (personneExiste == 1) {
						nomCreerPersonne.setText("");
						prenomCreerPersonne.setText("");
						dateDeNaissanceCreerPersonne.setText("");
						fonctionCreerPersonne.setText("");	
						layeredPane.setLayer(validationInformation, 2);	
					}
					else {
						errorMessageCreerPersonne.setText("Une personne existe d�j� avec ces informations");
					}
					
				}
				
			}
		});
		validerCreationPersonne.setBounds(252, 300, 89, 23);
		creerUnePersonne.add(validerCreationPersonne);
		
		JButton validerRecherchePersonneModif = new JButton("Valider");
		validerRecherchePersonneModif.setBounds(238, 237, 116, 41);
		rechercheModifPersonne.add(validerRecherchePersonneModif);
		validerRecherchePersonneModif.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if((rechercheNomPersonneModif.getText() == "") || (rechercherPrenomPersonneModif.getText() == "")) {
					
				}
				else {
					Personne personneModif = getPersonneDAO(rechercheNomPersonneModif.getText(), rechercherPrenomPersonneModif.getText());
					if (personneModif != null) {
						nomPersonneModif.setText(personneModif.getNom());
						fonctionPersonneModif.setText(personneModif.getFonction());
						prenomPersonneModif.setText(personneModif.getPrenom());
						int jour = personneModif.getDateDeNaissance().getDate();
						int mois = personneModif.getDateDeNaissance().getMonth() + 1;
						int annee = personneModif.getDateDeNaissance().getYear() + 1900;
						dateDeNaissancePersonneModif.setText(jour + "/" + mois  + "/" + annee);
						layeredPane_1.setLayer(rechercheModifPersonne, 0);
						layeredPane_1.setLayer(modifUnePersonne, 1);	
					}
					else {
						//Personne existe pas
				}
			}
		   }	
		});		
		
		JButton validationModifUnePersonne = new JButton("Valider");
		validationModifUnePersonne.setBounds(252, 300, 89, 23);
		modifUnePersonne.add(validationModifUnePersonne);
		validationModifUnePersonne.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				layeredPane.setLayer(validationInformation, 2);	
			}
		});	
		
		
		JButton listePersonneSupprimer = new JButton("Liste des personnes");
		listePersonneSupprimer.setBounds(425, 246, 159, 23);
		rechercheSupprimerPersonne.add(listePersonneSupprimer);
		listePersonneSupprimer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int nombrePersonneSupprimer = PersonneDAO.getList().size();
				System.out.println(nombrePersonneSupprimer);
				
				for (int i = 0; i < nombrePersonneSupprimer; i++ ){
					modeleSupprimer.addElement(PersonneDAO.getList().get(i).getPrenom() + " | | " + PersonneDAO.getList().get(i).getNom() + " | | " + PersonneDAO.getList().get(i).getFonction());
			    } 
			    

			    listSupprimerPersonneJList.setModel(modeleSupprimer);		    
				layeredPane_1_1.setLayer(rechercheSupprimerPersonne, 0);
				layeredPane_1_1.setLayer(listeSupprimerPersonne, 2);
				
			
				
				layeredPane_1_1.setLayer(rechercheSupprimerPersonne, 0);
				layeredPane_1_1.setLayer(listeSupprimerPersonne, 1);	
				

	        	ArrayList<Personne> ListeSupprimer = new ArrayList<>();
	        	
				listSupprimerPersonneJList.addMouseListener((MouseListener) new MouseAdapter() {
				    public void mouseClicked(MouseEvent evt) {
				        JList listSupprimerPersonneJList = (JList)evt.getSource();
				        if (evt.getClickCount() == 2) {
				        	int index = listSupprimerPersonneJList.locationToIndex(evt.getPoint());
				        	ListeSupprimer.add(PersonneDAO.getList().get(index));
							
				        }
					}    
				});		
				
				listeValidationSupprimerPersonne.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent ee) {
						for (int i = 0; i < ListeSupprimer.size(); i++ ) {
							PersonneDAO.delete(ListeSupprimer.get(i).getIdPersonne());
						}
						layeredPane_1_1.setLayer(rechercheSupprimerPersonne, 1);
						layeredPane_1_1.setLayer(listeSupprimerPersonne, 0);
						layeredPane.setLayer(validationInformation, 5);
						for (int j = modeleSupprimer.size() -1; j >= 0; j--) {
							modeleSupprimer.remove(j);	
						}
					}
					});	
				
				
			}
		});		
		
		
		//Display the list of person that we want to modify
		JButton listePersonneModif = new JButton("Liste des personnes");
		listePersonneModif.setBounds(423, 246, 161, 23);
		rechercheModifPersonne.add(listePersonneModif);
		listePersonneModif.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
				
				int nombrePersonneMofif = PersonneDAO.getList().size();		
				
				for (int i = 0; i < nombrePersonneMofif; i++ ){
			    	modeleModif.addElement(PersonneDAO.getList().get(i).getPrenom() + " | | " + PersonneDAO.getList().get(i).getNom() + " | | " + PersonneDAO.getList().get(i).getFonction());
			    } 
			    
			    listModifierPersonneJList.setModel(modeleModif);		    
				layeredPane_1.setLayer(rechercheModifPersonne, 0);
				layeredPane_1.setLayer(listeModifPersonne, 2);
				listeModifPersonne.add(scrollPaneModifier);
								
				
				listModifierPersonneJList.addMouseListener((MouseListener) new MouseAdapter() {
				    public void mouseClicked(MouseEvent evt) {
				        JList listModifierPersonneJList = (JList)evt.getSource();
				        if (evt.getClickCount() == 2) {
				        	int index = listModifierPersonneJList.locationToIndex(evt.getPoint());
				        	
				        	if (!(personneModif instanceof Personne)){
				        		personneModif = new Personne(PersonneDAO.getList().get(index).getIdPersonne(), PersonneDAO.getList().get(index).getNom(), PersonneDAO.getList().get(index).getPrenom(), PersonneDAO.getList().get(index).getDateDeNaissance(), PersonneDAO.getList().get(index).getFonction());
				        	}
				        	else {
				        		personneModif.setidPersonne(PersonneDAO.getList().get(index).getIdPersonne());
					        	personneModif.setPrenom(PersonneDAO.getList().get(index).getPrenom());
					        	personneModif.setNom(PersonneDAO.getList().get(index).getNom());
					        	personneModif.setFonction(PersonneDAO.getList().get(index).getFonction());
					        	personneModif.setDateDeNaissance(PersonneDAO.getList().get(index).getDateDeNaissance());
					        	
				        	}
				        	
				        	
				        	nomPersonneModif.setText(personneModif.getNom());
							fonctionPersonneModif.setText(personneModif.getFonction());
							prenomPersonneModif.setText(personneModif.getPrenom());
							int jour = personneModif.getDateDeNaissance().getDate();
							int mois = personneModif.getDateDeNaissance().getMonth() + 1;
							int annee = personneModif.getDateDeNaissance().getYear() + 1900;
							dateDeNaissancePersonneModif.setText(jour + "/" + mois  + "/" + annee);
							layeredPane_1.setLayer(listeModifPersonne, 0);
							layeredPane_1.setLayer(modifUnePersonne, 1);
							for (int j = modeleModif.size() -1; j >= 0; j--) {
								modeleModif.remove(j);	
							}
							
							validationModifUnePersonne.addActionListener(new ActionListener() {
								public void actionPerformed(ActionEvent e) {
									if ((nomPersonneModif.getText().length() <= 30) && (nomPersonneModif.getText().length() >= 2) && (fonctionPersonneModif.getText().length() <= 30) && (fonctionPersonneModif.getText().length() >= 2)  )  {
										personneModif.setNom(nomPersonneModif.getText());
										personneModif.setFonction(fonctionPersonneModif.getText());
										PersonneDAO.update(personneModif);

										System.out.println(personneModif.getFonction() + " " + personneModif.getNom() + " " + personneModif.getIdPersonne() + " " + personneModif.getPrenom());
										layeredPane_1.setLayer(modifUnePersonne, 0);
										layeredPane_1.setLayer(rechercheModifPersonne, 1);
									}
									else {
											errorMessageModifPersonne.setText("Un champ n'est pas valide");
									}
								}
							});	
							
				        }
					}    
				});		
		}
		});
		
		
	
		
		
		
		
		
		
		
		
		//Reporting / deconnection
		JButton reporting_1 = new JButton("Reporting");
		reporting_1.setBounds(10, 363, 89, 23);
		layeredPane.add(reporting_1);
		
		JButton deconnexion_1 = new JButton("D\u00E9connexion");
		deconnexion_1.setBounds(476, 363, 129, 23);
		layeredPane.add(deconnexion_1);
		deconnexion_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Login window = new Login();
				window.frame.setVisible(true);
				frmGestion.dispose();
			}
		});
		
		
		
		
		

		
		
		
		
		
		
		
		
		
		
		
		
		JLabel lblNewLabel = new JLabel("S\u00E9lectionnez une action");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblNewLabel.setBounds(10, 11, 595, 68);
		menugerer.add(lblNewLabel);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		layeredPane.setLayer(lblNewLabel, 1);
			
		JLabel lblGrerLesPersonnes = new JLabel("G\u00E9rer les personnes");
		lblGrerLesPersonnes.setHorizontalAlignment(SwingConstants.CENTER);
		lblGrerLesPersonnes.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblGrerLesPersonnes.setBounds(0, 0, 595, 68);
		gererLesPersonnesMenu.add(lblGrerLesPersonnes);
		
		JLabel lblNewLabel_2 = new JLabel("S\u00E9lectionnez une action");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2.setBounds(72, 78, 533, 36);
		gererLesPersonnesMenu.add(lblNewLabel_2);
	
		JLabel retour = new JLabel("Retour");
		layeredPane.setLayer(retour, 0);
		retour.setBounds(47, 5, 46, 14);
		layeredPane.add(retour);
		retour.setVisible(true);
		
		JLabel lblGrerLesPersonnes_1 = new JLabel("G\u00E9rer les lieux");
		lblGrerLesPersonnes_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblGrerLesPersonnes_1.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblGrerLesPersonnes_1.setBounds(10, 11, 595, 68);
		gererLesLieuxMenu.add(lblGrerLesPersonnes_1);
		
		JLabel lblNewLabel_2_1 = new JLabel("S\u00E9lectionnez une action");
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2_1.setBounds(72, 78, 533, 36);
		gererLesLieuxMenu.add(lblNewLabel_2_1);		
		
		JLabel lblGrerLesPersonnes_1_1 = new JLabel("G\u00E9rer les cartes");
		lblGrerLesPersonnes_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblGrerLesPersonnes_1_1.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblGrerLesPersonnes_1_1.setBounds(10, 11, 595, 68);
		gererLesCartesMenu.add(lblGrerLesPersonnes_1_1);
		
		JLabel lblNewLabel_2_1_1 = new JLabel("S\u00E9lectionnez une action");
		lblNewLabel_2_1_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_2_1_1.setBounds(72, 78, 533, 36);
		gererLesCartesMenu.add(lblNewLabel_2_1_1);
		
	
		JLabel lblNewLabel_1 = new JLabel("Cr\u00E9er une personne");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(10, 11, 595, 35);
		creerUnePersonne.add(lblNewLabel_1);
		
		JLabel lblNewLabel_3 = new JLabel("Compl\u00E9ter les champs suivants :");
		lblNewLabel_3.setBounds(65, 57, 227, 28);
		creerUnePersonne.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("Nom:");
		lblNewLabel_4.setBounds(95, 96, 48, 14);
		creerUnePersonne.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Pr\u00E9nom:");
		lblNewLabel_5.setBounds(95, 134, 48, 14);
		creerUnePersonne.add(lblNewLabel_5);
		
		JLabel lblNewLabel_5_1 = new JLabel("Fonction:");
		lblNewLabel_5_1.setBounds(95, 210, 89, 14);
		creerUnePersonne.add(lblNewLabel_5_1);
		
		JLabel lblNewLabel_4_1 = new JLabel("Date de naissance:");
		lblNewLabel_4_1.setBounds(95, 172, 115, 14);
		creerUnePersonne.add(lblNewLabel_4_1);
				
		JLabel lblNewLabel_6_1 = new JLabel("S\u00E9lectionnez la personne \u00E0 modifier");
		lblNewLabel_6_1.setBounds(108, 74, 246, 14);
		listeModifPersonne.add(lblNewLabel_6_1);
		
		JLabel lblNewLabel_6_1_1_1 = new JLabel("Modifier une personne");
		lblNewLabel_6_1_1_1.setBounds(0, 5, 615, 31);
		lblNewLabel_6_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 25));
		listeModifPersonne.add(lblNewLabel_6_1_1_1);
		
		JLabel lblNewLabel_6_1_1 = new JLabel("Modifier une personne");
		lblNewLabel_6_1_1.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblNewLabel_6_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6_1_1.setBounds(0, 0, 615, 56);
		rechercheModifPersonne.add(lblNewLabel_6_1_1);
		
		JLabel lblNewLabel_6 = new JLabel("Saisir le nom et le pr\u00E9nom de la personne \u00E0 modifier");
		lblNewLabel_6.setBounds(106, 66, 452, 14);
		rechercheModifPersonne.add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("Nom:");
		lblNewLabel_7.setBounds(106, 127, 46, 14);
		rechercheModifPersonne.add(lblNewLabel_7);
		
		JLabel lblNewLabel_7_1 = new JLabel("Pr\u00E9nom:");
		lblNewLabel_7_1.setBounds(106, 166, 101, 14);
		rechercheModifPersonne.add(lblNewLabel_7_1);
		
		JLabel errorMessageRechercheModifPersonne = new JLabel("");
		errorMessageRechercheModifPersonne.setBounds(182, 208, 322, 14);
		rechercheModifPersonne.add(errorMessageRechercheModifPersonne);
				
		JLabel lblNewLabel_1_1 = new JLabel("Modifier une personne");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblNewLabel_1_1.setBounds(10, 11, 595, 35);
		modifUnePersonne.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_3_1 = new JLabel("Saisissez les informations \u00E0 modifier");
		lblNewLabel_3_1.setBounds(95, 57, 227, 28);
		modifUnePersonne.add(lblNewLabel_3_1);
		
		JLabel lblNewLabel_4_2 = new JLabel("Nom:");
		lblNewLabel_4_2.setBounds(95, 96, 48, 14);
		modifUnePersonne.add(lblNewLabel_4_2);
		
		JLabel lblNewLabel_5_2 = new JLabel("Pr\u00E9nom:");
		lblNewLabel_5_2.setForeground(Color.GRAY);
		lblNewLabel_5_2.setBounds(95, 134, 48, 14);
		modifUnePersonne.add(lblNewLabel_5_2);
		
		JLabel lblNewLabel_5_1_1 = new JLabel("Fonction:");
		lblNewLabel_5_1_1.setBounds(95, 210, 48, 14);
		modifUnePersonne.add(lblNewLabel_5_1_1);
		
		JLabel lblNewLabel_4_1_1 = new JLabel("Date de naissance:");
		lblNewLabel_4_1_1.setForeground(Color.GRAY);
		lblNewLabel_4_1_1.setBounds(95, 172, 100, 14);
		modifUnePersonne.add(lblNewLabel_4_1_1);	
				
		JLabel lblNewLabel_6_1_1_2 = new JLabel("Supprimer une personne");
		lblNewLabel_6_1_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6_1_1_2.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblNewLabel_6_1_1_2.setBounds(0, 0, 615, 56);
		rechercheSupprimerPersonne.add(lblNewLabel_6_1_1_2);
		
		JLabel lblNewLabel_6_2 = new JLabel("Saisir le nom et le pr\u00E9nom de la personne \u00E0 supprimer");
		lblNewLabel_6_2.setBounds(106, 66, 452, 14);
		rechercheSupprimerPersonne.add(lblNewLabel_6_2);
		
		JLabel lblNewLabel_7_2 = new JLabel("Nom:");
		lblNewLabel_7_2.setBounds(106, 127, 46, 14);
		rechercheSupprimerPersonne.add(lblNewLabel_7_2);
		
		JLabel lblNewLabel_7_1_1 = new JLabel("Pr\u00E9nom:");
		lblNewLabel_7_1_1.setBounds(106, 166, 103, 14);
		rechercheSupprimerPersonne.add(lblNewLabel_7_1_1);		
				
		JLabel lblNewLabel_6_1_2 = new JLabel("S\u00E9lectionnez la ou les personnes \u00E0 supprimer");
		lblNewLabel_6_1_2.setBounds(108, 74, 327, 14);
		listeSupprimerPersonne.add(lblNewLabel_6_1_2);
		
		JLabel lblNewLabel_6_1_1_1_1 = new JLabel("Supprimer une personne");
		lblNewLabel_6_1_1_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6_1_1_1_1.setFont(new Font("Tahoma", Font.PLAIN, 25));
		lblNewLabel_6_1_1_1_1.setBounds(0, 5, 615, 31);
		listeSupprimerPersonne.add(lblNewLabel_6_1_1_1_1);
		
	
	
		JLabel lblNewLabel_9 = new JLabel("Vous allez est redirig\u00E9 vers le menu principal.");
		lblNewLabel_9.setBounds(125, 124, 383, 14);
		validationInformation.add(lblNewLabel_9);
		
		JLabel lblNewLabel_8 = new JLabel("Les informations ont bien \u00E9t\u00E9 enregistr\u00E9es.");
		lblNewLabel_8.setBounds(125, 90, 370, 23);
		validationInformation.add(lblNewLabel_8);
		}
	
	public Personne getPersonneDAO(String nom, String prenom) {
		return PersonneDAO.get(nom, prenom);
	}
	
	public String verificationCreerPersonne(String nom, String prenom, String date, String fonction) {
		if ((nomCreerPersonne.getText().length() <= 30) && (nomCreerPersonne.getText().length() >= 2) && (prenomCreerPersonne.getText().length() <= 30) && (prenomCreerPersonne.getText().length() >= 2) && (fonctionCreerPersonne.getText().length() <= 30) && (fonctionCreerPersonne.getText().length() >= 2)  )  {
			String[] dateTab = null;
			String str = date;				
			dateTab = str.split("/");		
			
			if (dateTab.length == 3) {
				if ((Integer.parseInt(dateTab[2]) <= 2021) && (Integer.parseInt(dateTab[2]) >= 1901) && (Integer.parseInt(dateTab[1]) <= 12) && (Integer.parseInt(dateTab[1]) >= 1) && (Integer.parseInt(dateTab[0]) <= 31) && (Integer.parseInt(dateTab[0]) >= 1)){			
					@SuppressWarnings("deprecation")
					Date dateDeNaissance = new Date (Integer.parseInt(dateTab[2])-1900,Integer.parseInt(dateTab[1])-1,Integer.parseInt(dateTab[0]));
					Personne personne = new Personne(nom, prenom, dateDeNaissance, fonction);
					this.personneExiste = PersonneDAO.create(personne);	
					
					return "ok";
					
				}
				else {
					return "Un champ n'est pas valide";	
					
				}					
			}
			else {
				return "Un champ n'est pas valide";	
				
			}			
		}else {
			return "Un champ n'est pas valide";
			
		}
	}	
}
