package Application;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class test {

	private JFrame frmDsfsqf;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					test window = new test();
					window.frmDsfsqf.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public test() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmDsfsqf = new JFrame();
		frmDsfsqf.setTitle("dsfsqf");
		frmDsfsqf.setBounds(100, 100, 707, 487);
		frmDsfsqf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmDsfsqf.getContentPane().setLayout(null);
		
		JLayeredPane layeredPane = new JLayeredPane();
		layeredPane.setBounds(0, 0, 691, 448);
		frmDsfsqf.getContentPane().add(layeredPane);
		
		JPanel panel_3 = new JPanel();
		layeredPane.setLayer(panel_3, 2);
		panel_3.setBounds(0, 0, 691, 437);
		layeredPane.add(panel_3);
		panel_3.setLayout(null);
		
		JPanel panel_2 = new JPanel();
		layeredPane.setLayer(panel_2, 2);
		panel_2.setBounds(0, 0, 691, 437);
		layeredPane.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("New label");
		lblNewLabel_2.setBounds(275, 9, 46, 14);
		panel_3.add(lblNewLabel_2);
		
		JButton btnNewButton = new JButton("New button");
		btnNewButton.setBounds(296, 133, 89, 23);
		panel_3.add(btnNewButton);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				layeredPane.setLayer(panel_2, 5);
			}
		});
		
		
		
		
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setBounds(146, 66, 46, 14);
		panel_2.add(lblNewLabel_1);
		
		JPanel panel = new JPanel();
		layeredPane.setLayer(panel, 1);
		panel.setBounds(0, 0, 691, 448);
		layeredPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setBounds(149, 145, 432, 81);
		panel.add(lblNewLabel);
	}
}
