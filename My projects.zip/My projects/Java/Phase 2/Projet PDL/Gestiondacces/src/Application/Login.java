package Application;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.plaf.basic.BasicButtonListener;


import javax.swing.JButton;
import java.awt.Button;

public class Login extends JFrame{

	JFrame frame;
	private JTextField identifiant;
	private JTextField motDePasse;
	private int tries = 0;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login window = new Login();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 631, 436);
		frame.setTitle("Authentification");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		//Text field's name
		JLabel lblNewLabel = new JLabel("Identifiant :");
		lblNewLabel.setBounds(169, 111, 106, 14);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Mot de passe");
		lblNewLabel_1.setBounds(169, 160, 106, 14);
		frame.getContentPane().add(lblNewLabel_1);
		
		
		//Text Field
		identifiant = new JTextField();
		identifiant.setBounds(310, 108, 147, 20);
		frame.getContentPane().add(identifiant);
		identifiant.setColumns(10);
		
		motDePasse = new JTextField();
		motDePasse.setBounds(310, 157, 147, 20);
		frame.getContentPane().add(motDePasse);
		motDePasse.setColumns(10);
		
		//Text login error
		
		JLabel errorText = new JLabel("ab");
		errorText.setHorizontalAlignment(SwingConstants.CENTER);
		errorText.setBounds(10, 228, 595, 14);
		errorText.setVisible(false);
		frame.getContentPane().add(errorText);
		errorText.setText("a");
		
		Button valider = new Button("Valider");
		valider.setBounds(275, 312, 70, 22);
		frame.getContentPane().add(valider);
		valider.addActionListener(new ActionListener(){ 
			public void actionPerformed(ActionEvent e) {
				if ((identifiant.getText().equals("a")) && (motDePasse.getText().equals("a"))) {
					Authorized();
					}
				else {
					tries += 1;
					System.out.println(tries);
					if ((1 <= tries) && (tries <3)) { 
						errorText.setText("Mauvais identifiant/Mot de passe");
						errorText.setVisible(true);
					}
					if (tries >= 3) { 
						errorText.setText("Vous avez d�pass� le nombre de tentative autoris�");
						errorText.setVisible(true);
					
					}
				}
					
			}
		});
		
		
	}
	
	private void Authorized() {
		try {
			MenuGestion gestion = new MenuGestion(0);
			gestion.getJFrame().setVisible(true);
			frame.dispose();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	
	}


