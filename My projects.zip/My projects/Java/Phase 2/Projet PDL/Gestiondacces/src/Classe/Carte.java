package Classe;

public class Carte {
	
	private int numero;
	private int etatBlocageCarte;
	private Personne personne;
	
	public Carte(Personne personne) {
		this.personne = personne;
	}
	
	public Carte(int numero, Personne personne) {
		this.personne = personne;
		this.numero = numero;
	}
	
	public Carte(int numero, int etatBlocageCarte) {
		this.personne = personne;
		this.numero = numero;
	}
	
	
	public void setnumero(int numero) {
		this.numero = numero;
	}
	
	public int getNumero(){
		return numero;
	}
	
	public Personne getPersonne() {
		return personne;
	}
	
	public void getEtatBlocageCarte(int etatBlocageCarte) {
		this.etatBlocageCarte = etatBlocageCarte;
	}
	
	public int getEtatBlocageCarte() {
		return etatBlocageCarte;
	}
	
	
	public void display() {
		System.out.println("Numero:" + numero);
		if (etatBlocageCarte == 0)
			System.out.println("Etat blocage carte: D�bloqu�");
		else
			System.out.println("Etat Blocage carte: Bloqu�");
	}


	
}
