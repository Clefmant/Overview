/**
* Class person
*
* @author  Cl�ment Sieuw 
* @author2  Boubacar Ndoffane Diakhate
* @version 1.0
* @since   2021-03-22 
*/


package Classe;

import java.sql.Date;

public class Personne {

	private String nom;
	private String prenom;
	private Date dateDeNaissance;
	private String fonction;
	private int idpersonne;
	private int idCarte;
	
	
	/**
	 * Instantiation
	 * @param nom name of the person	
	 * @param prenom surname of the person
	 * @param dateDeNaissance birth date of the person	
	 * @param fonction job of the person
	 */
	public Personne (String nom, String prenom, Date dateDeNaissance, String fonction) {
		this.nom = nom;
		this.prenom = prenom;
		this.dateDeNaissance = dateDeNaissance;
		this.fonction = fonction;
	}	
	
	public Personne (String nom, String prenom, Date dateDeNaissance, String fonction, int idCarte) {
		this.nom = nom;
		this.prenom = prenom;
		this.dateDeNaissance = dateDeNaissance;
		this.fonction = fonction;
		this.idCarte = idCarte;
	}
	
	public Personne (int idpersonne, String nom, String prenom, Date dateDeNaissance, String fonction) {
		this.idpersonne = idpersonne;
		this.nom = nom;
		this.prenom = prenom;
		this.dateDeNaissance = dateDeNaissance;
		this.fonction = fonction;
	}
	
	
	public String getNom() {
		return nom;
	}
	
	public String getPrenom() {
		return prenom;
	}
	
	public Date getDateDeNaissance() {
		return dateDeNaissance;
	}
	
	public String getFonction() {
		return fonction;
	}
	
	
	public int getIdPersonne() {
		return idpersonne;
	}
	

	public void setidPersonne(int idPersonne) {
		this.idpersonne = idPersonne;
	}
	
	
	public void setNom(String nom) {
		this.nom = nom;
	}
	
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	
	public void setDateDeNaissance(Date dateDeNaissance) {
		this.dateDeNaissance = dateDeNaissance;
	}
	
	public void setFonction(String fonction) {
		this.fonction = fonction;
	}
	
	public void setCarte(int idCarte) {
		this.idCarte = idCarte;
	}

	
	
	
	
	
	
	public void display () {
		System.out.println("Nom:" + getNom());
		System.out.println("Prenom:" + getPrenom());
		System.out.println("Date de naissance:" + getDateDeNaissance());
		System.out.println("Fonction:" + getFonction());
	}
	
	
	
	
}
